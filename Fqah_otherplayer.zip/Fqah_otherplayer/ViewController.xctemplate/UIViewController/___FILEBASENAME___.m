//
//   /\_/\
//   \_ _/
//    / \ not
//    \_/
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import "___FILEBASENAME___.h"

@interface ___FILEBASENAME___ ()

@end

@implementation ___FILEBASENAME___

#pragma mark - LifeCircle

- (void)initModel{
    // 初始化Model
    
}
- (void)initView{
    // 初始化View
    
}
- (void)initData{
    // 初始化Data
    
}

#pragma mark - Network Methods

#pragma mark - Action

#pragma mark - Delegate

#pragma mark - Private

#pragma mark - Configure







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
