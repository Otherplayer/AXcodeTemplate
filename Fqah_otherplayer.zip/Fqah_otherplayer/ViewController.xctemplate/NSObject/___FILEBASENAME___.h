//
//   /\_/\
//   \_ _/
//    / \ not
//    \_/
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//___COPYRIGHT___
//

#import <Foundation/Foundation.h>

@interface ___FILEBASENAMEASIDENTIFIER___ : ___VARIABLE_cocoaSubclass___

// custom code

@end
